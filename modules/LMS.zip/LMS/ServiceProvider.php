<?php

namespace Modules\Lms;

use Illuminate\Support\ServiceProvider;

class LmsServiceProvider extends ServiceProvider
{
    // The LMS package is intentionally an empty, installable extension shell.
}
