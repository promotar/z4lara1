<?php

use Illuminate\Support\Facades\Route;
use Modules\ArtInpaAdminProTheme\Http\Controllers\AdminThemeSettingsController;

Route::get('/admin/plugins/admin-theme/settings', [AdminThemeSettingsController::class, 'index'])
    ->name('admin.plugins.admin-theme.settings');
