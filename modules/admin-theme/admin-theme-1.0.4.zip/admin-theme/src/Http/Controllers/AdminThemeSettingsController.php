<?php

namespace Modules\ArtInpaAdminProTheme\Http\Controllers;

use Illuminate\Contracts\View\View;

class AdminThemeSettingsController
{
    public function index(): View
    {
        return view('admin-theme::settings', [
            'themeVersion' => '1.0.4',
        ]);
    }
}
