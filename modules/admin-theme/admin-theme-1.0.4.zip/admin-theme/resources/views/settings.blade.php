<x-app-layout>
    <x-slot name="header">
        <div class="admin-theme-settings-heading">
            <div>
                <span>Appearance</span>
                <h2>Admin Theme</h2>
            </div>

            <a href="{{ route('admin.plugins.index') }}">Back to plugins</a>
        </div>
    </x-slot>

    <div class="admin-theme-settings-page">
        <section class="admin-theme-settings-panel">
            <div class="admin-theme-settings-status">
                <span class="admin-theme-settings-mark">A</span>
                <div>
                    <h3>Art INPA Admin Theme</h3>
                    <p>The protected default theme is active.</p>
                </div>
                <strong>Version {{ $themeVersion }}</strong>
            </div>

            <dl class="admin-theme-settings-details">
                <div>
                    <dt>Navigation</dt>
                    <dd>Compact, always-open hierarchy</dd>
                </div>
                <div>
                    <dt>Fallback</dt>
                    <dd>Restored when another admin theme is disabled</dd>
                </div>
                <div>
                    <dt>Scope</dt>
                    <dd>Administration dashboard only</dd>
                </div>
            </dl>
        </section>
    </div>
</x-app-layout>
